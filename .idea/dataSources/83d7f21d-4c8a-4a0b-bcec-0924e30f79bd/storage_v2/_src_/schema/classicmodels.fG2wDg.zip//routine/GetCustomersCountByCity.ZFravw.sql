create
    definer = root@localhost procedure GetCustomersCountByCity(IN in_city varchar(50), OUT total int)
begin
        SELECT customerName, COUNT(customerNumber)

        INTO total

        FROM customers

        WHERE city = in_city;
    end;

